package com.cg.conference.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
//payment details page bean
public class PaymentDetailsPageBean {

	@FindBy(how=How.NAME,name="txtFN")
	private WebElement cardHolderName;
	
	@FindBy(how=How.NAME,name="debit")
	private WebElement debitCardNumber;
	
	@FindBy(how=How.NAME,name="cvv")
	private WebElement cvv;
	
	@FindBy(how=How.NAME,name="month")
	private WebElement expirationMonth;
	
	@FindBy(how=How.NAME,name="year")
	private WebElement expirationYear;
	
	@FindBy(how=How.ID_OR_NAME,id="btnPayment")
	private WebElement submit;

	public String getCardHolderName() {
		return cardHolderName.getAttribute("value");
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public String getDebitCardNumber() {
		return debitCardNumber.getAttribute("value");
	}

	public void setDebitCardNumber(String debitCardNumber) {
		this.debitCardNumber.sendKeys(debitCardNumber);
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public String getExpirationMonth() {
		return expirationMonth.getAttribute("value");
	}

	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth.sendKeys(expirationMonth);
	}

	public String getExpirationYear() {
		return expirationYear.getAttribute("value");
	}

	public void setExpirationYear(String expirationYear) {
		this.expirationYear.sendKeys(expirationYear);
	}

	public void clickSubmit() {
		submit.submit();
	}
	
	
}
