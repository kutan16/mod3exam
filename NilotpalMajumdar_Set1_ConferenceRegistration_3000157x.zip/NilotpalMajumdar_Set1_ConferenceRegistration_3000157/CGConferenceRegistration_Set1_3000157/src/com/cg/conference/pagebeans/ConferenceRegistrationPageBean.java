package com.cg.conference.pagebeans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
//conference registration page bean
public class ConferenceRegistrationPageBean {
	
	@FindBy(how=How.NAME,name="txtFN")
	private WebElement firstName;
	
	@FindBy(how=How.NAME,name="txtLN")
	private WebElement lastName;
	
	@FindBy(how=How.NAME,name="Email")
	private WebElement email;
	
	@FindBy(how=How.NAME,name="txtPhone")
	private WebElement contactNo;
	
	@FindBy(how=How.NAME,name="size")
	private List<WebElement> NoOfPeopleAttending;
	
	@FindBy(how=How.NAME,name="Address")
	private WebElement buildingNameAndRoomNo;
	
	@FindBy(how=How.NAME,name="Address2")
	private WebElement areaName;
	
	@FindBy(how=How.NAME,name="city")
	private WebElement city;
	
	@FindBy(how=How.NAME,name="state")
	private WebElement state;
	
	@FindBy(how=How.NAME,name="memberStatus")
	private List<WebElement> memberStatus;

	@FindBy(how=How.LINK_TEXT,linkText="Next")
	private WebElement next;
	
	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}

	public String getContactNo() {
		return contactNo.getAttribute("value");
	}

	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);
	}

	public String getNoOfPeopleAttending() {
		for (WebElement webElement : NoOfPeopleAttending) 
			if(webElement.isSelected())
				return webElement.getAttribute("value");
			return null;
	}

	public void setNoOfPeopleAttending(String noOfPeopleAttending) {
		if(noOfPeopleAttending.equals("1"))
		this.NoOfPeopleAttending.get(0).click();
	else if(noOfPeopleAttending.equals("2"))
		this.NoOfPeopleAttending.get(1).click();
	else if(noOfPeopleAttending.equals("3"))
		this.NoOfPeopleAttending.get(2).click();
	else if(noOfPeopleAttending.equals("4"))
		this.NoOfPeopleAttending.get(3).click();
	else if(noOfPeopleAttending.equals("5"))
		this.NoOfPeopleAttending.get(4).click();
	else
		this.NoOfPeopleAttending.get(5).click();
	}

	public String getBuildingNameAndRoomNo() {
		return buildingNameAndRoomNo.getAttribute("value");
	}

	public void setBuildingNameAndRoomNo(String buildingNameAndRoomNo) {
		this.buildingNameAndRoomNo.sendKeys(buildingNameAndRoomNo);
	}

	public String getAreaName() {
		return areaName.getAttribute("value");
	}

	public void setAreaName(String areaName) {
		this.areaName.sendKeys(areaName);
	}

	public String getCity() {
		return new Select(this.city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		Select select=new Select(this.city);
		select.selectByVisibleText(city);
	}

	public String getState() {
		return new Select(this.state).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		Select select=new Select(this.state);
		select.selectByVisibleText(state);
	}

	public String getMemberStatus() {
		for (WebElement webElement : memberStatus) 
			if(webElement.isSelected())
				return webElement.getAttribute("value");
			return null;
	}

	public void setMemberStatus(String memberStatus) {
		if(memberStatus.equalsIgnoreCase("member"))
			this.memberStatus.get(0).click();
		else 
			this.memberStatus.get(1).click();
	}

	public void clickRegister() {
		next.click();
	}
	
}
