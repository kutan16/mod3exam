package com.cg.conference.test;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
//conference registration test runner
@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"features"},
		glue= {"com.cg.conference.stepdefinition"}
	)
public class ConferenceRegistrationTest {

}
