package com.cg.conference.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.conference.pagebeans.ConferenceRegistrationPageBean;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
//conference registration step definition
public class ConferenceRegistrationStepDefinition {
	private WebDriver driver;

	private ConferenceRegistrationPageBean pageBean;
	//setting up test environment
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\ADM-IG-HWDLAB1D\\Desktop\\NilotpalMajumdar_Set1_ConferenceRegistration_3000157\\chromedriver.exe" );
		driver=new ChromeDriver();	
	}
	//all definitions for features		
	@Given("^User is accessing Conference Regsitrtion Page on Borwser$")
	public void user_is_accessing_Conference_Regsitrtion_Page_on_Borwser() throws Throwable {
		driver.get("D:\\Users\\ADM-IG-HWDLAB1D\\Desktop\\NilotpalMajumdar_Set1_ConferenceRegistration_3000157\\Set B\\ConferenceRegistartion.html");
		pageBean = PageFactory.initElements(driver, ConferenceRegistrationPageBean.class);
	    throw new PendingException();
	}

	@When("^User is trying submit data without entering 'First Name'$")
	public void user_is_trying_submit_data_without_entering_First_Name() throws Throwable {
	    pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please fill the First Name' alert message should display$")
	public void please_fill_the_First_Name_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the First Name";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entering 'Last Name'$")
	public void user_is_trying_to_submit_request_without_entering_Last_Name() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setFirstName("Nilotpal");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please fill the Last Name' alert message should display$")
	public void please_fill_the_Last_Name_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the Last Name";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entring 'Email'$")
	public void user_is_trying_to_submit_request_without_entring_Email() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setLastName("Majumdar");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please fill the Email' alert message should display$")
	public void please_fill_the_Email_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the Email";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entring  valid 'Email'$")
	public void user_is_trying_to_submit_request_without_entring_valid_Email() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setEmail("nilotpal#gmail.com");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please enter valid Email Id\\.' alert message should display$")
	public void please_enter_valid_Email_Id_alert_message_should_display() throws Throwable {
		String expectedAlertMessage="Please enter valid Email Id.";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entering 'Contact No'$")
	public void user_is_trying_to_submit_request_without_entering_Contact_No() throws Throwable {
		pageBean.setEmail("nilotpal@gamil.com");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please fill the Contact No\\.' alert message should display$")
	public void please_fill_the_Contact_No_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the Contact No.";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entering valid 'Contact No'$")
	public void user_is_trying_to_submit_request_without_entering_valid_Contact_No() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setContactNo("1234567890");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please enter valid Contact no\\.' alert message should display$")
	public void please_enter_valid_Contact_no_alert_message_should_display() throws Throwable {
		String expectedAlertMessage="Please enter valid Contact no.";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without selecting 'No\\. of people attending'$")
	public void user_is_trying_to_submit_request_without_selecting_No_of_people_attending() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setContactNo("7003399682");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please fill the Number of people attending' alert message should display$")
	public void please_fill_the_Number_of_people_attending_alert_message_should_display() throws Throwable {
		String expectedAlertMessage="Please fill the Number of people attending";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entering 'Building Name & Room No\\.'$")
	public void user_is_trying_to_submit_request_without_entering_Building_Name_Room_No() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setFirstName("Nilotpal");
		pageBean.setLastName("Majumdar");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please fill the Building & Room No' alert message should display$")
	public void please_fill_the_Building_Room_No_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the Building & Room No";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entering 'Area Name'$")
	public void user_is_trying_to_submit_request_without_entering_Area_Name() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setLastName("Majumdar");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please fill the Area name' alert message should display$")
	public void please_fill_the_Area_name_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the Area name";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without selecting  valid 'City'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_City() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setAreaName("Hinjewadi");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please select city' alert message should display$")
	public void please_select_city_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please select city";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without entring   valid 'State'$")
	public void user_is_trying_to_submit_request_without_entring_valid_State() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setAreaName("Hinjewadi");
		pageBean.setCity("Pune");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please select state' alert message should display$")
	public void please_select_state_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please select state";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request without selecting  'Membership Status'$")
	public void user_is_trying_to_submit_request_without_selecting_Membership_Status() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setCity("Pune");
		pageBean.setState("Maharashtra");
		pageBean.clickRegister();
	    throw new PendingException();
	}

	@Then("^'Please Select MemeberShip status' alert message should display$")
	public void please_Select_MemeberShip_status_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please Select MemeberShip status";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}

	@When("^User is trying to submit request by clicking on next after entering valid set of information$")
	public void user_is_trying_to_submit_request_by_clicking_on_next_after_entering_valid_set_of_information() throws Throwable {
	    pageBean.setFirstName("Nilotpal");
	    pageBean.setLastName("Majumdar");
	    pageBean.setEmail("nilotpal@gmail.com");
	    pageBean.setContactNo("7003399682");
	    pageBean.setNoOfPeopleAttending("3");
	    pageBean.setBuildingNameAndRoomNo("Manas,room1D");
	    pageBean.setAreaName("Hinjewadi");
	    pageBean.setCity("Pune");
	    pageBean.setState("Maharashtra");
	    pageBean.setMemberStatus("Conference full-Access(member)(1000 Rs.)");
	    throw new PendingException();
	}

	@Then("^'Personal Details are Validated' alert message should display$")
	public void personal_Details_are_Validated_alert_message_should_display() throws Throwable {
		String expectedAlertMessage="Personal Details are Validated";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	    throw new PendingException();
	}
	//closing environment
	@After
	public void tearDownStepEnv() {
		driver.switchTo().alert().dismiss();
		driver.close();
	}

}
